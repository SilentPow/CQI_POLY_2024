#ifndef MY_BOT_H
#define MY_BOT_H

char *get_command(char *spaceship_message_json);
char *send_messages(char *game_message_json);

#endif // MY_BOT_H
